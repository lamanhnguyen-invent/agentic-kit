# rates-api

Serves currency exchange rates.

- Install: `npm install`
- Run: `npm start`
- Test: `npm test`
- `src/api/` holds the HTTP handlers, `src/rates.ts` the lookup logic.
- Use 2-space indentation and named exports.
