---
paths:
  - "src/api/**"
---
All API handlers validate input with Zod before processing.
