export function rate(from: string, to: string): number {
  return 1;
}
