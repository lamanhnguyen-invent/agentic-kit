# shop monorepo

- Install: `pnpm install`
- Test: `pnpm test`
- Use 2-space indentation.
