# shop monorepo

- Install: `pnpm install`
- Test: `pnpm test`
- Use 2-space indentation.

## Layout

- `packages/web/` — the storefront (React)
- `packages/billing/` — invoices and payments

## Billing package

In `packages/billing/`, amounts are integers in cents, never floats. Every
public function takes a `currency` argument. Invoice numbers come from
`nextInvoiceNumber()`, never from a counter in the caller.
