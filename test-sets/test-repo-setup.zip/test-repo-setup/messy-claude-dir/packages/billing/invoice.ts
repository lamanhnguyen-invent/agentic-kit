export function nextInvoiceNumber(): string {
  return "INV-0001";
}
