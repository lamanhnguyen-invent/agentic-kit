Write the changelog entry for the current branch:

1. Run `git log main..HEAD --oneline`.
2. Group the commits into Added, Changed and Fixed.
3. Add the entry at the top of `CHANGELOG.md` under today's date.
