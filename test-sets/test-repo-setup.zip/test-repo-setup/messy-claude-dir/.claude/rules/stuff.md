React components in `packages/web/src/**/*.tsx` are function components
with named exports. No default exports.

Use tabs for indentation.
