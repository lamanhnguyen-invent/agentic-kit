1. Run `pnpm test`.
2. Run `pnpm version minor` in the package to release.
3. Push the tag.
