# report-tool

Builds weekly PDF reports from a CSV export.

- Run: `uv run python -m src.report <file.csv>`
- Test: `uv run pytest`

## Releasing

1. Run `uv run pytest`.
2. Bump the version in `pyproject.toml`.
3. Tag the commit `v<version>` and push the tag.
4. Attach the built wheel to the release.

## Invent Project Guidelines (v0.5)

Repo type: **prod** (`INVENT_REPO_TYPE` in `.claude/settings.json`; don't
change it yourself).

Suggested workflow for bigger changes or tickets. It is not enforced;
small, low-risk changes don't need it. It pays off most in code you don't
know yet.

1. **Grill it** — stress-test the approach against the code and existing
   docs: ask the user to run `/grill-with-docs` (only the user can start
   it), or invoke the `grilling` and `domain-modeling` skills yourself.
2. **Plan it** — create the feature branch, then write the plan to
   `plans/<branch name without prefix>.md` (`feature/PROJ-123-login` →
   `plans/PROJ-123-login.md`) using the template below. Every acceptance
   criterion names the test or command that proves it. Then apply
   `ponytail` to the plan to strip it to the simplest version that meets
   the criteria.
3. **Approve it** — point the user to the plan file and wait for their
   approval before writing code. They may edit the file directly.
4. **Implement it** — on the feature branch, never on main/master.
   Delegate to subagents capped at Sonnet (no higher-tier model per
   subagent); tell each one to read the plan file, which step to
   implement, and to follow this CLAUDE.md and the `ponytail` skill.
5. **Verify it** — run the test for every acceptance criterion and the
   pre-commit hooks; fix until green. Tick each criterion in the plan
   file once its test passes.
6. **Review it** — run the `pr-review` agent on the branch; it reads the
   plan file itself and runs on Opus (the Sonnet cap is for implementing
   subagents only). Address its findings before opening the PR.

Commit the plan file with the change, so reviewers see what was asked.

Plan template:

    # <ticket id> <title>

    ## Goal
    One sentence: what and why.

    ## Acceptance criteria
    - [ ] <observable behaviour> — Test: <test name or command>

    ## Steps
    1. ...

    ## Out of scope
    - ...

### Invent tooling (v0.5)

- **Pre-tool-use hooks (active):** `protect-secrets` (Read/Edit/Write/Grep/
  Bash/PowerShell), `block-dangerous-commands` and `git-safety`
  (Bash/PowerShell). `git-safety` blocks commits, merges, rebases,
  resets and pushes on main/master — work on a feature branch.
- **Session-start hook (active):** `ponytail-activate` loads the
  `ponytail` ruleset into every session.
- **Deny rules:** `.claude/settings.json` blocks reading and editing
  secret files (`.env`, keys, credentials). Don't work around them.
- **Pre-commit hooks:** Python complexity (radon/xenon), lint and format
  (ruff), optional type check (ty) — blocking in this prod repo; see
  `.pre-commit-config.yaml`. Never bypass them with `--no-verify`: if a
  hook blocks, fix the reported issue once; if it still fails, stop and
  ask the user.
- **Testing guidelines:** none yet — TBD.

If the user asks what Invent's hooks/pre-commit/testing setup is, report
exactly the state above — don't invent details beyond what's listed.
