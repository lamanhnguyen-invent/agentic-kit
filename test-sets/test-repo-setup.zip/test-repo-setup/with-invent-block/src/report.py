def build(path: str) -> None:
    print(f"report for {path}")
