# Test repos for /repo-setup on its own

Each folder is its own git repo with one commit, so `git status` and
`git diff` show what a run changed. Open Claude Code in the folder and run
`/repo-setup`. In every repo with findings, expect the numbered list, then
all / pick / none, then the backup-folder question and the confirmation
before the first write.

| Folder | Expect |
|---|---|
| `overgrown/` | Six findings in `CLAUDE.md` (below). Try "let me pick" with two of them: only those are applied. Then run the restore command. (AC9) |
| `empty/` | No `CLAUDE.md`: `/init` starts, or you are told to type it. No backup. (AC7) |
| `agents-only/` | Proposes a `CLAUDE.md` with the single line `@AGENTS.md`; no `/init`. (AC8) |
| `messy-claude-dir/` | Findings in `.claude/` and across files (below). |
| `with-invent-block/` | One finding: "Releasing" → skill. No finding on the "Invent Project Guidelines" section, although it holds a six-step workflow. |
| `clean/` | "Nothing needs to change", no backup, no writes. |

`overgrown/CLAUDE.md`:

1. "Deploying" — a multi-step procedure → skill (P-13)
2. "API handlers" — applies to `src/api/` only → path-scoped rule (P-10)
3. "Never read or edit `.env`" → `permissions.deny` (P-15)
4. "Run `ruff format` after every edit" → hook, command known (P-14)
5. "I prefer short answers in German" → `CLAUDE.local.md`, added to `.gitignore` (P-16)
6. "Format code properly" — too vague to verify → reword or delete (P-03)

`messy-claude-dir/`:

1. `CLAUDE.md` repeats `AGENTS.md` → `@AGENTS.md` import (P-05)
2. "Billing package" section → `packages/billing/CLAUDE.md` (P-12)
3. `.claude/rules/stuff.md` names `packages/web/src/**/*.tsx` but has no `paths:` (P-11), and its name says nothing (P-20)
4. "Use tabs" in that rule contradicts "Use 2-space indentation" (P-04)
5. `.claude/commands/changelog.md` → a skill named `changelog` (P-13)
6. `.claude/skills/release/SKILL.md` has no `name` and `description` (P-21)
7. `permissions.allow` in `settings.json` must survive unchanged

To check `--no-questions` without the kit: `/repo-setup --no-questions` in
`overgrown/` asks nothing, backs up to `./.repo-setup-backup` and applies
all six.

Reset a repo to its starting state:

    git checkout . && git clean -fdx
