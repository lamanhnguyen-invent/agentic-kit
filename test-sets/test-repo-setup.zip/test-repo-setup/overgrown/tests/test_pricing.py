from src.core.pricing import total


def test_total():
    assert total([1.10, 2.20]) == 3.30
