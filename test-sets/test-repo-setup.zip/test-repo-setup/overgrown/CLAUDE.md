# orders-service

A small FastAPI service that takes orders and writes them to Postgres.

## Commands

- Install: `uv sync`
- Run: `uv run uvicorn src.main:app --reload`
- Test: `uv run pytest`
- Lint: `uv run ruff check .`

## Layout

- `src/api/` — HTTP handlers, one file per resource
- `src/core/` — business logic, no HTTP or database imports
- `tests/` — pytest, mirrors `src/`

## Conventions

- Python 3.12, type hints on every public function.
- Use 4-space indentation.
- Format code properly.

## API handlers

Every handler in `src/api/` validates its input with a Pydantic model before
calling into `src/core/`. Handlers return a response model, never a raw dict.
Handlers never open a database session themselves; they take one through
`Depends(get_session)`.

## Deploying

1. Run `uv run pytest` and make sure everything passes.
2. Bump the version in `pyproject.toml`.
3. Build the image: `docker build -t orders-service:<version> .`
4. Push it: `docker push registry.example.com/orders-service:<version>`
5. Update the tag in `deploy/values.yaml` and open a PR against `infra`.
6. After the PR is merged, check `https://orders.example.com/health`.
7. Post the version and the changelog in the team channel.

## Rules

- Never read or edit `.env`.
- Run `ruff format` after every edit to a Python file.
- I prefer short answers in German.
