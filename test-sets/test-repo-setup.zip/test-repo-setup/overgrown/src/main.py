from fastapi import FastAPI

from src.api.orders import router

app = FastAPI()
app.include_router(router)
