from fastapi import APIRouter
from pydantic import BaseModel

from src.core.pricing import total

router = APIRouter()


class OrderIn(BaseModel):
    prices: list[float]


class OrderOut(BaseModel):
    total: float


@router.post("/orders")
def create_order(order: OrderIn) -> OrderOut:
    return OrderOut(total=total(order.prices))
