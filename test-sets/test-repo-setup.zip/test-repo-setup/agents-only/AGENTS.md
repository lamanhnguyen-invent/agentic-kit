# notes-cli

A Node CLI that stores notes as Markdown files.

- Install: `npm install`
- Test: `npm test`
- Entry point: `bin/notes.js`
- Use 2-space indentation and single quotes.
