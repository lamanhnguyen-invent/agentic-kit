# Test repos for /agentic-kit-setup and /repo-setup

Each folder is its own git repo with one commit, so `git status` and
`git diff` show what a run changed. Open Claude Code in the folder and run
the command.

| Folder | Run | Expect |
|---|---|---|
| `overgrown/` | `/agentic-kit-setup` | Two timestamped folders in `.repo-setup-backup/`, the first before any write. No question from repo-setup. Six findings applied (see below). Invent block untouched. The second restore command undoes only the restructuring; the first brings back the original files. (AC11) |
| `overgrown/` | `/repo-setup` on its own | Backup-folder question, confirmation, then all / pick / none. (AC9) |
| `empty/` | `/agentic-kit-setup` | Nothing to back up. `/init` runs before the Invent block is added. (AC12) |
| `agents-only/` | `/agentic-kit-setup` | `AGENTS.md` is backed up. `CLAUDE.md` is created with `@AGENTS.md`, not by `/init`, then the Invent block is added. |

Findings planted in `overgrown/CLAUDE.md`:

1. "Deploying" — a multi-step procedure → skill (P-13)
2. "API handlers" — applies to `src/api/` only → path-scoped rule (P-10)
3. "Never read or edit `.env`" → `permissions.deny` (P-15)
4. "Run `ruff format` after every edit" → hook, command known (P-14)
5. "I prefer short answers in German" → `CLAUDE.local.md` (P-16)
6. "Format code properly" — too vague to verify → reword or delete (P-03)

Reset a repo to its starting state:

    git checkout . && git clean -fdx
